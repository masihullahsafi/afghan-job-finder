
require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const nodemailer = require('nodemailer');

const app = express();
app.use(cors());
app.use(express.json({ limit: '50mb' })); // Large limit for CVs/Images

// --- SCHEMAS ---

const JobSchema = new mongoose.Schema({
  id: String,
  employerId: String,
  title: String,
  company: String,
  companyLogo: String,
  location: String,
  salaryMin: Number,
  salaryMax: Number,
  currency: String,
  type: String,
  experienceLevel: String,
  category: String,
  postedDate: String,
  deadline: String,
  description: String,
  requirements: [String],
  responsibilities: [String],
  status: String,
  applyMethod: String,
  applyUrl: String,
  isFeatured: Boolean,
  isUrgent: Boolean,
  
  // Detailed Fields
  vacancyNumber: String,
  noOfJobs: Number,
  contractDuration: String,
  contractExtensible: Boolean,
  probationPeriod: String,
  gender: String,
  education: String,
  nationality: String,
  yearsOfExperience: String
});

const UserSchema = new mongoose.Schema({
  id: String,
  firstName: String, 
  lastName: String, 
  name: String,
  email: { type: String, unique: true },
  role: String, 
  avatar: String,
  bio: String,
  title: String,
  password: { type: String, required: true },
  resumeData: String, 
  plan: String,
  status: String,
  
  // Verification Fields
  isVerified: { type: Boolean, default: false },
  verificationToken: String,
  verificationTokenExpires: Date,
  verificationStatus: { type: String, default: 'Unverified' },
  verificationDocument: String, // NEW: Stores Base64 of license

  // Enhanced Profile Fields
  jobTitle: String,
  phone: String,
  country: String,
  city: String,
  address: String,
  dob: String,
  
  // Company Specific Fields
  website: String,
  industry: String,
  companyDetails: Object,
  youtubeUrl: String,
  banner: String,
  socialLinks: Object,
  gallery: [String],

  // Seeker Specific Fields
  verifiedSkills: [String],
  experience: Array,
  education: Array,
  documents: Array,
  
  // Settings & Relations
  settings: Object,
  following: [String],
  savedCandidates: [String]
});

const ApplicationSchema = new mongoose.Schema({
  id: String,
  jobId: String,
  seekerId: String,
  employerId: String,
  resumeData: String,
  coverLetter: String,
  status: String,
  date: String,
  interviewDate: String,
  interviewTime: String,
  interviewMessage: String,
  employerNotes: String,
  employerRating: Number,
  timeline: Array,
  screeningAnswers: Array,
  rejectionReason: String
});

const Job = mongoose.model('Job', JobSchema);
const User = mongoose.model('User', UserSchema);
const Application = mongoose.model('Application', ApplicationSchema);

// --- SEED DEFAULT ADMIN ---
const seedAdmin = async () => {
  try {
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash("admin123", salt);
    
    // Force update/create admin
    await User.findOneAndUpdate(
      { email: "admin@afghanjobfinder.com" }, 
      {
        id: "admin_seed",
        name: "Super Admin",
        email: "admin@afghanjobfinder.com",
        password: hashedPassword,
        role: "ADMIN",
        status: "Active",
        plan: "Premium",
        avatar: "https://ui-avatars.com/api/?name=Admin&background=be0000&color=fff",
        isVerified: true
      },
      { upsert: true, new: true }
    );
    
    console.log("------------------------------------------------");
    console.log("✅ ADMIN READY");
    console.log("📧 Email: admin@afghanjobfinder.com");
    console.log("🔑 Pass:  admin123");
    console.log("------------------------------------------------");
  } catch (e) {
    console.error("❌ Admin Seeding Error:", e);
  }
};

mongoose.connect(process.env.MONGO_URI)
  .then(async () => {
    console.log("✅ Connected to MongoDB");
    await seedAdmin();
  })
  .catch((err) => console.error("❌ Database Connection Error:", err));

// --- EMAIL CONFIGURATION ---
const transporter = nodemailer.createTransport({
  host: process.env.EMAIL_HOST || 'md-plesk-web6.webhostbox.net',
  port: parseInt(process.env.EMAIL_PORT || '465'),
  secure: process.env.EMAIL_SECURE === 'true',
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS
  },
  tls: {
    rejectUnauthorized: false
  }
});

// --- ROUTES ---

// 1. JOBS
app.get('/api/jobs', async (req, res) => {
  try {
    const jobs = await Job.find().sort({ postedDate: -1 });
    res.json(jobs);
  } catch(e) { res.status(500).json({error: e.message}) }
});

app.post('/api/jobs', async (req, res) => {
  try {
    const newJob = new Job(req.body);
    await newJob.save();
    res.json(newJob);
  } catch(e) { res.status(400).json({error: e.message}) }
});

app.put('/api/jobs/:id', async (req, res) => {
    try {
        const updated = await Job.findOneAndUpdate({ id: req.params.id }, req.body, { new: true });
        res.json(updated);
    } catch(e) { res.status(500).json({error: e.message}) }
});

app.delete('/api/jobs/:id', async (req, res) => {
  try {
    await Job.deleteOne({ id: req.params.id });
    res.json({ success: true });
  } catch(e) { res.status(500).json({error: e.message}) }
});

// 2. USERS (AUTH & VERIFICATION)

app.get('/api/users', async (req, res) => {
    try {
        const users = await User.find().select('-password -verificationToken');
        res.json(users);
    } catch(e) { res.status(500).json({error: e.message}) }
});

app.post('/api/login', async (req, res) => {
  const { email, password, role } = req.body;
  
  try {
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(401).json({ message: "User not found." });
    }

    if (user.role !== role) {
        return res.status(403).json({ message: `Access denied. This account is for ${user.role}s.` });
    }

    const isMatch = await bcrypt.compare(password, user.password);
    if (isMatch) {
      const { password: _, verificationToken: __, ...userData } = user.toObject();
      res.json(userData);
    } else {
      res.status(401).json({ message: "Invalid password." });
    }
  } catch (e) {
    console.error("Login Error:", e);
    res.status(500).json({ message: "Server error during login." });
  }
});

app.post('/api/register', async (req, res) => {
  try {
    const { password, email, firstName, ...otherData } = req.body;

    const existingUser = await User.findOne({ email });
    if (existingUser) {
        return res.status(400).json({ message: "User with this email already exists." });
    }

    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    const otpExpires = new Date(Date.now() + 3600000); 

    const newUser = new User({
      ...otherData,
      email,
      firstName,
      name: `${firstName} ${otherData.lastName || ''}`,
      password: hashedPassword,
      verificationToken: otp,
      verificationTokenExpires: otpExpires,
      isVerified: false,
      status: 'Pending',
      following: [],
      savedCandidates: []
    });

    await newUser.save();

    const mailOptions = {
        from: `"Afghan Job Finder" <${process.env.EMAIL_USER}>`,
        to: email,
        subject: 'Verify Your Email - Afghan Job Finder',
        html: `
            <div style="font-family: Arial, sans-serif; padding: 20px; color: #333;">
                <h2 style="color: #0284c7;">Welcome to Afghan Job Finder!</h2>
                <p>Hi ${firstName},</p>
                <p>Thank you for registering. Please use the code below to verify your email address:</p>
                <h1 style="background: #f0f9ff; padding: 10px; border-radius: 5px; display: inline-block; color: #0284c7; letter-spacing: 5px;">${otp}</h1>
                <p>This code will expire in 1 hour.</p>
            </div>
        `
    };

    try {
        await transporter.sendMail(mailOptions);
    } catch(emailErr) {
        console.error("Failed to send email:", emailErr);
    }
    
    res.json({ success: true, requireVerification: true, email: email });

  } catch (e) {
    console.error(e);
    res.status(500).json({ message: "Registration failed. " + e.message });
  }
});

app.post('/api/verify-email', async (req, res) => {
    const { email, otp } = req.body;
    try {
        const user = await User.findOne({ email, verificationToken: otp });

        if (!user) return res.status(400).json({ message: "Invalid OTP." });

        user.isVerified = true;
        user.verificationToken = undefined;
        user.verificationTokenExpires = undefined;
        user.status = 'Active'; 
        await user.save();

        const { password: _, ...userData } = user.toObject();
        res.json({ success: true, user: userData });

    } catch (e) {
        res.status(500).json({ message: "Verification failed." });
    }
});

// NEW: Upload Verification Document (e.g. Business License)
app.post('/api/upload-verification', async (req, res) => {
    const { userId, documentData } = req.body;
    try {
        await User.findOneAndUpdate(
            { id: userId }, 
            { 
                verificationDocument: documentData, 
                verificationStatus: 'Pending' 
            }
        );
        res.json({ success: true });
    } catch(e) {
        res.status(500).json({ error: e.message });
    }
});

app.put('/api/users/:id', async (req, res) => {
  try {
    if (req.body.password) {
        const salt = await bcrypt.genSalt(10);
        req.body.password = await bcrypt.hash(req.body.password, salt);
    }
    await User.findOneAndUpdate({ id: req.params.id }, req.body);
    res.json({ success: true });
  } catch(e) { res.status(500).json({error: e.message}) }
});

// 3. APPLICATIONS
app.get('/api/applications', async (req, res) => {
  try {
    const apps = await Application.find();
    res.json(apps);
  } catch(e) { res.status(500).json({error: e.message}) }
});

app.post('/api/applications', async (req, res) => {
  try {
    const newApp = new Application(req.body);
    await newApp.save();
    res.json(newApp);
  } catch(e) { res.status(400).json({error: e.message}) }
});

app.put('/api/applications/:id', async (req, res) => {
  try {
    await Application.findOneAndUpdate({ id: req.params.id }, req.body);
    res.json({ success: true });
  } catch(e) { res.status(500).json({error: e.message}) }
});

const PORT = 5000;
app.listen(PORT, () => console.log(`🚀 Full Stack Server running on ${PORT}`));
